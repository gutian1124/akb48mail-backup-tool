#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AKB48 Mail STEP2 本文＋画像バックアップ v1.2

Step1で作成した mail_list_all.csv などを読み、
各 detail_url（無ければ mail_id から生成）へアクセスして、
本文と画像を保存します。

主な仕様:
- 最大処理メール数を任意指定（0=全部）
- 1ネットワーク要求ごとに最低0.5秒間隔（変更可）
- 本文＋画像
- メンバー別フォルダ
- 途中再開（既存ファイルはスキップ）
- 429 / 5xx はバックオフして再試行
- 401 / 403 は停止
- Request Headers / Access-Token 等は保存しない
"""

from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit
import csv
import html
import mimetypes
import os
import re
import threading
import time
import traceback
import urllib.request
import urllib.error
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

DETAIL_HOST = "web.akb48mail-appli.com"
IMAGE_HOST = "img.akb48mail-appli.com"

SKIP_HEADERS = {
    "host", "content-length", "connection", "proxy-connection",
    "accept-encoding", "if-none-match", "transfer-encoding",
}

# 画像CDNへ認証トークン等を無用に送らないため、画像取得ではこの程度だけ利用
IMAGE_HEADER_ALLOW = {
    "user-agent", "accept", "accept-language", "referer",
}


class AuthAccessError(Exception):
    """HTTP 401/403専用。OSのPermissionErrorと区別する。"""
    pass

def parse_headers(raw):
    headers = {}
    last_key = None

    for raw_line in raw.replace("\r\n", "\n").split("\n"):
        line = raw_line.strip()
        if not line:
            continue

        if re.match(r"^(GET|POST|HEAD|PUT|DELETE|PATCH|OPTIONS)\s+", line, re.I):
            continue

        if line.startswith(":"):
            continue

        if ":" not in line:
            if last_key:
                headers[last_key] = headers[last_key] + " " + line
            continue

        key, value = line.split(":", 1)
        key, value = key.strip(), value.strip()

        if not key:
            last_key = None
            continue
        if key.lower() in SKIP_HEADERS:
            # 除外ヘッダーの継続行を直前の許可ヘッダーへ連結しない。
            last_key = None
            continue

        headers[key] = value
        last_key = key

    return headers


def image_headers_from(detail_headers):
    out = {}
    for k, v in detail_headers.items():
        if k.lower() in IMAGE_HEADER_ALLOW:
            out[k] = v

    # ブラウザ由来のAcceptがHTML専用の場合は画像向けに緩める
    out["Accept"] = "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
    return out


class MailDetailParser(HTMLParser):
    """#mail-detail 内の本文テキストと img src を抜く。"""

    BLOCK_TAGS = {
        "div", "p", "br", "li", "section", "article",
        "h1", "h2", "h3", "h4", "h5", "h6"
    }
    # HTMLでは終了タグを持たないため、深さに含めない。
    VOID_TAGS = {
        "area", "base", "br", "col", "embed", "hr", "img", "input",
        "link", "meta", "param", "source", "track", "wbr",
    }

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_target = False
        self.depth = 0
        self.parts = []
        self.images = []

    def handle_starttag(self, tag, attrs):
        attrs_dict = dict(attrs)

        if not self.in_target and attrs_dict.get("id") == "mail-detail":
            self.in_target = True
            self.depth = 1
            return

        if self.in_target:
            if tag not in self.VOID_TAGS:
                self.depth += 1

            if tag == "img":
                src = attrs_dict.get("src")
                if src:
                    self.images.append(src)

            if tag in self.BLOCK_TAGS:
                self.parts.append("\n")

    def handle_startendtag(self, tag, attrs):
        if self.in_target:
            attrs_dict = dict(attrs)
            if tag == "img":
                src = attrs_dict.get("src")
                if src:
                    self.images.append(src)
            if tag == "br":
                self.parts.append("\n")

    def handle_endtag(self, tag):
        if self.in_target:
            if tag in self.BLOCK_TAGS:
                self.parts.append("\n")

            if tag not in self.VOID_TAGS:
                self.depth -= 1
                if self.depth <= 0:
                    self.in_target = False
                    self.depth = 0

    def handle_data(self, data):
        if self.in_target:
            self.parts.append(data)

    def get_text(self):
        text = html.unescape("".join(self.parts))
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        text = re.sub(r"[ \t]+\n", "\n", text)
        text = re.sub(r"\n[ \t]+", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def get_images(self):
        seen = set()
        out = []
        for u in self.images:
            if u not in seen:
                seen.add(u)
                out.append(u)
        return out


class RateLimiter:
    def __init__(self, interval):
        self.interval = max(0.0, float(interval))
        self.last_time = 0.0
        self.lock = threading.Lock()

    def wait(self):
        with self.lock:
            now = time.monotonic()
            elapsed = now - self.last_time
            remaining = self.interval - elapsed
            if remaining > 0:
                time.sleep(remaining)
            self.last_time = time.monotonic()


def http_get(url, headers, limiter, timeout=45):
    limiter.wait()
    req = urllib.request.Request(url, headers=headers, method="GET")

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", resp.getcode())
            body = resp.read()
            return status, body, resp.headers

    except urllib.error.HTTPError as e:
        body = e.read()
        return e.code, body, e.headers


def request_with_retry(url, headers, limiter, log, binary=False, max_retries=5):
    attempt = 0

    while True:
        status, body, resp_headers = http_get(url, headers, limiter)

        if status == 200:
            if binary:
                return body, resp_headers

            try:
                charset = resp_headers.get_content_charset() or "utf-8"
            except Exception:
                charset = "utf-8"

            return body.decode(charset, errors="replace"), resp_headers

        if status in (401, 403):
            try:
                text = body.decode("utf-8", errors="replace")
            except Exception:
                text = ""

            raise AuthAccessError(
                f"HTTP {status}: 認証・アクセス系エラーのため停止します.\n"
                f"レスポンス先頭500文字:\n{text[:500]}"
            )

        if status == 429 or 500 <= status <= 599:
            if attempt >= max_retries:
                raise RuntimeError(
                    f"HTTP {status}: {max_retries}回再試行しても取得できませんでした。"
                )

            try:
                ra = resp_headers.get("Retry-After")
                wait = float(ra) if ra else min(5 * (2 ** attempt), 60)
            except Exception:
                wait = min(5 * (2 ** attempt), 60)

            log(f"    HTTP {status} → {wait:.1f}秒待って再試行")
            time.sleep(wait)
            attempt += 1
            continue

        try:
            text = body.decode("utf-8", errors="replace")
        except Exception:
            text = ""

        raise RuntimeError(
            f"HTTP {status}: 取得できませんでした。\n"
            f"URL: {url}\n"
            f"レスポンス先頭500文字:\n{text[:500]}"
        )


def safe_filename(s, limit=90):
    s = str(s or "").strip()
    s = re.sub(r'[\\/:*?"<>|]', "_", s)
    s = re.sub(r"\s+", " ", s)
    s = s.strip(" .")
    return (s[:limit] or "unknown")


def normalize_mail_id(raw):
    raw = str(raw or "").strip()
    m = re.search(r"(m\d+)", raw)
    return m.group(1) if m else raw


def get_detail_url(row):
    url = str(row.get("detail_url") or "").strip()
    if url.startswith("https://"):
        return url

    mail_id = normalize_mail_id(row.get("mail_id"))
    if not mail_id:
        return ""

    return f"https://{DETAIL_HOST}/mail/{mail_id}"


def detect_image_extension(url, headers):
    # URLに拡張子があれば優先
    suffix = Path(urlsplit(url).path).suffix.lower()
    if suffix and len(suffix) <= 6:
        return suffix

    try:
        ctype = headers.get_content_type()
    except Exception:
        ctype = None

    if ctype:
        ext = mimetypes.guess_extension(ctype)
        if ext:
            if ext == ".jpe":
                return ".jpg"
            return ext

    return ".jpg"


def load_csv(path):
    rows = []
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = [x or "" for x in (reader.fieldnames or [])]

        if "mail_id" not in fieldnames:
            raise ValueError(
                "CSVに mail_id 列がありません。\n"
                "STEP1で作成した STEP2入力用_全メール一覧.csv を選んでください。"
            )

        for row in reader:
            mid = normalize_mail_id(row.get("mail_id"))
            if not mid:
                continue
            row["mail_id"] = mid
            rows.append(row)

    return rows


def existing_backup_is_complete(txt_path, image_dir, mail_id, save_images):
    """既存本文を完了印として扱えるかを確認する。"""
    if not txt_path.exists():
        return False
    if not save_images:
        return True

    try:
        saved_text = txt_path.read_text(encoding="utf-8")
    except Exception:
        return False

    count_match = re.search(r"^画像数:\s*(\d+)\s*$", saved_text, re.MULTILINE)
    if not count_match:
        # 画像欄のない正常な旧バックアップ（画像0枚）との互換性を保つ。
        return True

    expected = int(count_match.group(1))
    for n in range(1, expected + 1):
        matches = [
            path for path in image_dir.glob(f"{mail_id}_{n:02d}.*")
            if path.is_file() and path.stat().st_size > 0
        ]
        if not matches:
            return False
    return True


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AKB48 Mail STEP2 本文＋画像バックアップ v1.2")
        self.geometry("960x850")
        self.minsize(820, 720)
        self.running = False
        self.csv_path = tk.StringVar()

        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        ttk.Label(
            root,
            text="① STEP1の「STEP2入力用_全メール一覧.csv」を選択",
            font=("", 11, "bold")
        ).pack(anchor="w")

        row = ttk.Frame(root)
        row.pack(fill="x", pady=(4, 14))

        ttk.Entry(row, textvariable=self.csv_path).pack(
            side="left", fill="x", expand=True
        )
        ttk.Button(row, text="参照", command=self.choose_csv).pack(
            side="left", padx=(8, 0)
        )

        ttk.Label(
            root,
            text="② メール詳細ページの Request Headers を貼り付け",
            font=("", 11, "bold")
        ).pack(anchor="w")

        ttk.Label(
            root,
            text="例: GET /mail/mxxxxx の成功リクエスト。先頭のGET行ごと貼ってもOKです。"
        ).pack(anchor="w", pady=(2, 4))

        self.headers_text = tk.Text(root, height=17, wrap="none")
        self.headers_text.pack(fill="both", expand=True)

        opts1 = ttk.Frame(root)
        opts1.pack(fill="x", pady=(12, 6))

        ttk.Label(opts1, text="処理メール数（0=全部）:").pack(side="left")
        self.max_mails_var = tk.StringVar(value="10")
        ttk.Entry(opts1, width=8, textvariable=self.max_mails_var).pack(
            side="left", padx=(6, 18)
        )

        ttk.Label(opts1, text="通信間隔（秒）:").pack(side="left")
        self.interval_var = tk.StringVar(value="0.5")
        ttk.Entry(opts1, width=8, textvariable=self.interval_var).pack(
            side="left", padx=(6, 18)
        )

        self.save_images_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            opts1,
            text="画像も保存",
            variable=self.save_images_var
        ).pack(side="left")

        opts2 = ttk.Frame(root)
        opts2.pack(fill="x", pady=(0, 10))

        self.skip_existing_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            opts2,
            text="既に保存済みのメールはスキップ（途中再開）",
            variable=self.skip_existing_var
        ).pack(side="left")

        self.start_btn = ttk.Button(
            opts2,
            text="バックアップ開始",
            command=self.start
        )
        self.start_btn.pack(side="right")

        ttk.Separator(root).pack(fill="x", pady=(0, 10))

        ttk.Label(root, text="進捗", font=("", 11, "bold")).pack(anchor="w")
        self.log_text = tk.Text(root, height=16, state="disabled")
        self.log_text.pack(fill="both", expand=True, pady=(4, 0))

    def choose_csv(self):
        path = filedialog.askopenfilename(
            title="STEP2入力用_全メール一覧.csv を選択",
            filetypes=[
                ("CSVファイル", "*.csv"),
                ("すべてのファイル", "*.*"),
            ]
        )
        if path:
            self.csv_path.set(path)

    def log(self, text):
        self.after(0, self._log_ui, text)

    def _log_ui(self, text):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def start(self):
        if self.running:
            return

        try:
            csv_path = Path(self.csv_path.get().strip())
            if not csv_path.exists():
                raise ValueError("STEP1のCSVを選択してください。")

            rows = load_csv(csv_path)
            if not rows:
                raise ValueError("CSVに処理できるMail IDがありません。")

            if csv_path.name != "STEP2入力用_全メール一覧.csv":
                if not messagebox.askyesno(
                    "CSV確認",
                    "通常は STEP2入力用_全メール一覧.csv を選びます。\n\n"
                    f"現在選択中: {csv_path.name}\n\n"
                    "このCSVのまま続けますか？"
                ):
                    return

            raw_headers = self.headers_text.get("1.0", "end").strip()
            headers = parse_headers(raw_headers)
            if not headers:
                raise ValueError("メール詳細ページのRequest Headersを貼り付けてください。")

            max_mails = int(self.max_mails_var.get())
            if max_mails < 0:
                raise ValueError("処理メール数は0以上にしてください。")

            interval = float(self.interval_var.get())
            if interval < 0:
                raise ValueError("通信間隔は0以上にしてください。")

        except Exception as e:
            messagebox.showerror("入力エラー", str(e))
            return

        lower = {k.lower(): v for k, v in headers.items()}
        missing = [x for x in ("user-id", "access-token") if x not in lower]

        if missing:
            if not messagebox.askyesno(
                "確認",
                "次のヘッダーが見つかりません:\n"
                + "\n".join(missing)
                + "\n\nそれでも試しますか？"
            ):
                return

        save_dir = filedialog.askdirectory(
            title="バックアップ結果の保存先を選択"
        )
        if not save_dir:
            return

        self.running = True
        self.start_btn.configure(state="disabled")
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

        threading.Thread(
            target=self.worker,
            args=(
                rows,
                headers,
                max_mails,
                interval,
                self.save_images_var.get(),
                self.skip_existing_var.get(),
                Path(save_dir),
            ),
            daemon=True,
        ).start()

    def worker(
        self,
        rows,
        headers,
        max_mails,
        interval,
        save_images,
        skip_existing,
        save_dir
    ):
        try:
            root_dir = save_dir / "AKBメールバックアップ"
            root_dir.mkdir(parents=True, exist_ok=True)

            # 保存先の書き込み権限を最初に確認
            self.log(f"保存先確認: {root_dir}")
            test_path = root_dir / "_書き込みテスト.tmp"
            try:
                test_path.write_text("write test", encoding="utf-8")
                test_path.unlink()
                self.log("保存先書き込みテスト: OK")
            except Exception as e:
                self.log("保存先書き込みテスト: ERROR")
                self.log(f"{type(e).__name__}: {repr(e)}")
                self.log(traceback.format_exc())
                raise

            limiter = RateLimiter(interval)
            img_headers = image_headers_from(headers)

            target_rows = rows[:max_mails] if max_mails else rows
            total = len(target_rows)

            self.log(f"対象メール: {total}件")
            self.log(f"通信間隔: {interval}秒 / 1ネットワーク要求")
            self.log(f"画像保存: {'ON' if save_images else 'OFF'}")
            self.log(f"途中再開: {'ON' if skip_existing else 'OFF'}")
            self.log("")

            ok_count = 0
            skip_count = 0
            error_count = 0
            image_count = 0
            errors = []

            for idx, row in enumerate(target_rows, 1):
                mail_id = normalize_mail_id(row.get("mail_id"))
                member_id = str(row.get("member_id") or "unknown").strip()
                member_name = str(row.get("member_name") or "unknown").strip()
                receive_dt = str(
                    row.get("receive_datetime")
                    or row.get("receive_time")
                    or ""
                ).strip()

                member_dir = root_dir / f"{safe_filename(member_name)}_{safe_filename(member_id)}"
                text_dir = member_dir / "本文"
                image_dir = member_dir / "画像"
                text_dir.mkdir(parents=True, exist_ok=True)
                if save_images:
                    image_dir.mkdir(parents=True, exist_ok=True)

                # 日付をファイル名に少しだけ使う
                date_prefix = re.sub(r"[^0-9]", "", receive_dt)[:14]
                if date_prefix:
                    txt_name = f"{date_prefix}_{mail_id}.txt"
                else:
                    txt_name = f"{mail_id}.txt"

                txt_path = text_dir / txt_name

                if skip_existing and txt_path.exists():
                    if existing_backup_is_complete(
                        txt_path, image_dir, mail_id, save_images
                    ):
                        self.log(f"[{idx}/{total}] {mail_id} ... SKIP（保存済み）")
                        skip_count += 1
                        continue
                    self.log(
                        f"[{idx}/{total}] {mail_id} ... "
                        "既存本文に未保存画像があるため再開"
                    )

                detail_url = get_detail_url(row)
                if not detail_url:
                    msg = f"{mail_id}: detail_urlを作れません"
                    self.log(f"[{idx}/{total}] {msg}")
                    errors.append(msg)
                    error_count += 1
                    continue

                try:
                    host = urlsplit(detail_url).hostname
                    if host != DETAIL_HOST:
                        raise RuntimeError(
                            f"想定外のdetail_urlホストです: {host}"
                        )

                    self.log(f"[{idx}/{total}] {mail_id} 本文取得中...")
                    self.log(f"    URL: {detail_url}")

                    html_text, _ = request_with_retry(
                        detail_url,
                        headers,
                        limiter,
                        self.log,
                        binary=False
                    )

                    parser = MailDetailParser()
                    parser.feed(html_text)

                    body_text = parser.get_text()
                    # 相対URLも詳細ページ基準で絶対URLに直してからホスト検査する。
                    image_urls = [
                        urljoin(detail_url, image_url)
                        for image_url in parser.get_images()
                    ]

                    if not body_text and "mail-detail" not in html_text:
                        raise RuntimeError(
                            "#mail-detail が見つかりませんでした。"
                        )

                    downloaded_images = []
                    image_failed = False

                    if save_images and image_urls:
                        for n, img_url in enumerate(image_urls, 1):
                            try:
                                img_host = urlsplit(img_url).hostname
                                if img_host != IMAGE_HOST:
                                    raise RuntimeError(
                                        "想定外ホストのため取得しません "
                                        f"({img_host})"
                                    )

                                # 本文がまだ無い部分再開では、取得済み画像を再利用する。
                                # 拡張子はContent-Type由来の場合もあるため番号で探す。
                                existing_images = sorted(
                                    path
                                    for path in image_dir.glob(
                                        f"{mail_id}_{n:02d}.*"
                                    )
                                    if path.is_file()
                                    and path.stat().st_size > 0
                                )
                                if skip_existing and existing_images:
                                    img_name = existing_images[0].name
                                    downloaded_images.append(
                                        (img_name, img_url)
                                    )
                                    self.log(
                                        f"    画像{n}/{len(image_urls)} "
                                        f"SKIP（保存済み: {img_name}）"
                                    )
                                    continue

                                self.log(
                                    f"    画像{n}/{len(image_urls)} 取得中..."
                                )

                                data, resp_headers = request_with_retry(
                                    img_url,
                                    img_headers,
                                    limiter,
                                    self.log,
                                    binary=True
                                )

                                ext = detect_image_extension(
                                    img_url,
                                    resp_headers
                                )
                                img_name = f"{mail_id}_{n:02d}{ext}"
                                img_path = image_dir / img_name

                                if not (
                                    skip_existing and img_path.exists()
                                ):
                                    img_path.write_bytes(data)

                                downloaded_images.append(
                                    (img_name, img_url)
                                )
                                image_count += 1

                            except AuthAccessError:
                                raise
                            except Exception as e:
                                self.log(f"    画像{n}: ERROR {e}")
                                errors.append(
                                    f"{mail_id} 画像{n}: {e}"
                                )
                                error_count += 1
                                image_failed = True

                    # 本文ファイルが途中再開の完了印になるため、画像保存ON時に
                    # 1枚でも失敗したメールは本文を書かず、次回の再開対象に残す。
                    if image_failed:
                        self.log(
                            "    未完了: 取得できなかった画像があるため、"
                            "次回の途中再開対象に残します。"
                        )
                        continue

                    lines = [
                        f"Mail ID: {mail_id}",
                        f"メンバー: {member_name}",
                        f"Member ID: {member_id}",
                    ]

                    if receive_dt:
                        lines.append(f"受信日時: {receive_dt}")

                    subject = str(row.get("subject") or "").strip()
                    if subject:
                        lines.append(f"件名: {subject}")

                    lines += [
                        f"Detail URL: {detail_url}",
                        "",
                        "----- 本文 -----",
                        body_text,
                    ]

                    if image_urls:
                        lines += [
                            "",
                            "----- 画像 -----",
                            f"画像数: {len(image_urls)}",
                        ]

                        for n, img_url in enumerate(image_urls, 1):
                            local_name = ""
                            for d_name, d_url in downloaded_images:
                                if d_url == img_url:
                                    local_name = d_name
                                    break

                            if local_name:
                                lines.append(
                                    f"{n}. {local_name}\n   {img_url}"
                                )
                            else:
                                lines.append(f"{n}. {img_url}")

                    # 本文が取れた最後にtxtを書く
                    # → 途中で落ちた場合、再開時に再処理できる
                    txt_path.write_text(
                        "\n".join(lines),
                        encoding="utf-8"
                    )

                    self.log(
                        f"    OK / 本文{len(body_text)}文字 / "
                        f"画像URL{len(image_urls)}件"
                    )
                    ok_count += 1

                except AuthAccessError:
                    raise

                except PermissionError:
                    raise

                except Exception as e:
                    msg = f"{mail_id}: {e}"
                    self.log(f"    ERROR: {e}")
                    errors.append(msg)
                    error_count += 1

            summary = [
                "AKB48 Mail STEP2 本文＋画像バックアップ v1.2",
                "",
                f"対象メール: {total}",
                f"成功: {ok_count}",
                f"保存済みスキップ: {skip_count}",
                f"エラー件数: {error_count}",
                f"保存画像数: {image_count}",
                f"通信間隔: {interval}秒",
                f"画像保存: {'ON' if save_images else 'OFF'}",
                "",
                "※ Request Headers / User-Id / Access-Token は保存していません。",
            ]

            if errors:
                summary += [
                    "",
                    "----- エラー詳細 -----",
                    *errors,
                ]

            (root_dir / "バックアップ結果.txt").write_text(
                "\n".join(summary),
                encoding="utf-8-sig"
            )

            self.log("")
            self.log("完了！")
            self.log(
                f"成功{ok_count} / SKIP{skip_count} / "
                f"エラー{error_count} / 画像{image_count}"
            )
            self.log(f"保存先: {root_dir}")

            self.after(
                0,
                lambda: messagebox.showinfo(
                    "完了",
                    f"バックアップ完了\n\n"
                    f"成功: {ok_count}\n"
                    f"保存済みスキップ: {skip_count}\n"
                    f"エラー: {error_count}\n"
                    f"保存画像: {image_count}\n\n"
                    f"保存先:\n{root_dir}"
                )
            )

        except AuthAccessError as e:
            self.log("")
            self.log("HTTP認証・アクセス系エラーで停止しました。")
            self.log(str(e))
            self.after(
                0,
                lambda err=str(e): messagebox.showerror(
                    "停止",
                    err
                )
            )

        except PermissionError as e:
            tb = traceback.format_exc()
            self.log("")
            self.log("Windows / ファイル権限系の PermissionError が発生しました。")
            self.log(f"{type(e).__name__}: {repr(e)}")
            self.log(tb)
            try:
                (save_dir / "AKB_STEP2_エラー診断.txt").write_text(
                    f"{type(e).__name__}: {repr(e)}\n\n{tb}",
                    encoding="utf-8-sig"
                )
            except Exception:
                pass
            self.after(
                0,
                lambda err=repr(e): messagebox.showerror(
                    "PermissionError",
                    "Windows側のPermissionErrorです。\n\n"
                    + err
                    + "\n\n進捗欄に詳細なTracebackを表示しました。"
                )
            )

        except Exception as e:
            self.log("")
            self.log("致命的エラー:")
            self.log(f"{type(e).__name__}: {repr(e)}")
            self.log(traceback.format_exc())
            self.after(
                0,
                lambda err=str(e): messagebox.showerror(
                    "エラー",
                    err
                )
            )

        finally:
            self.running = False
            self.after(
                0,
                lambda: self.start_btn.configure(state="normal")
            )


if __name__ == "__main__":
    App().mainloop()
