﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    py "AKB_STEP2_本文画像バックアップ_v1_2.py"
) else (
    python "AKB_STEP2_本文画像バックアップ_v1_2.py"
)
if errorlevel 1 pause
