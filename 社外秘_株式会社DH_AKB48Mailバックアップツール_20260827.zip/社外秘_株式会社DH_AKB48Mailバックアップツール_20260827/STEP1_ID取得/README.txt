﻿AKB48 Mail STEP1 ID取得 v5

出力ファイル名を分かりやすく整理しました。

STEP2で選ぶファイル:
  STEP2入力用_全メール一覧.csv

その他:
  全MailID一覧.txt
  確認用_メンバー別_メンバー名_ID.csv
  確認用_メンバー別_メンバー名_ID.txt
  STEP1取得結果.txt

「どのCSVをSTEP2に入れるか」で迷ったら、
STEP2入力用_全メール一覧.csv を選んでください。

総合テスト修正:
- If-None-Matchなど除外対象ヘッダーの折り返し行も安全に除外
