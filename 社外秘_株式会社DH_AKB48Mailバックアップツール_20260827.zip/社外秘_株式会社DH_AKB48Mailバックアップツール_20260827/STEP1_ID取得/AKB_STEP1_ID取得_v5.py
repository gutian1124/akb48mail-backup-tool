#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
AKB48 Mail API ID取得ツール v2
- メンバー未選択の /v1/inbox を推奨
- member_id が無ければ全体一覧として全ページ取得
- JSON内の member.id / member.name で自動的にメンバー別出力
- member_id 付きURLもそのまま利用可能
"""

from pathlib import Path
import csv
import json
import time
import re
import threading
import traceback
import urllib.request
import urllib.error
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

ALLOWED_HOST = "api.akb48mail-appli.com"
SKIP_HEADERS = {
    "host", "content-length", "connection", "proxy-connection",
    "accept-encoding", "if-none-match", "transfer-encoding",
}

FIELDS = [
    "mail_id", "receive_datetime", "receive_time", "subject",
    "member_id", "member_name", "detail_url", "is_image",
    "is_unread", "is_star", "source_page", "content_preview",
]

def parse_headers(raw):
    headers = {}
    last_key = None
    for raw_line in raw.replace("\r\n", "\n").split("\n"):
        line = raw_line.strip()
        if not line:
            continue
        if re.match(r"^(GET|POST|HEAD|PUT|DELETE|PATCH|OPTIONS)\s+", line, re.I):
            continue
        if line.startswith(":"):
            continue
        if ":" not in line:
            if last_key:
                headers[last_key] = headers[last_key] + " " + line
            continue
        key, value = line.split(":", 1)
        key, value = key.strip(), value.strip()
        if not key:
            last_key = None
            continue
        if key.lower() in SKIP_HEADERS:
            # 除外ヘッダーの継続行を直前の許可ヘッダーへ連結しない。
            last_key = None
            continue
        headers[key] = value
        last_key = key
    return headers

def validate_url(url):
    p = urlsplit(url.strip())
    if p.scheme != "https":
        raise ValueError("URLは https:// から始まるものを貼ってください。")
    if p.hostname != ALLOWED_HOST:
        raise ValueError(f"このツールは {ALLOWED_HOST} 専用です。\n入力されたホスト: {p.hostname}")
    if p.path != "/v1/inbox":
        raise ValueError(f"このツールは /v1/inbox 専用です。\n入力されたパス: {p.path}")

def query_dict(url):
    p = urlsplit(url.strip())
    return dict(parse_qsl(p.query, keep_blank_values=True))

def set_page(url, page):
    p = urlsplit(url.strip())
    pairs = parse_qsl(p.query, keep_blank_values=True)
    found = False
    out = []
    for k, v in pairs:
        if k == "page":
            if not found:
                out.append(("page", str(page)))
                found = True
        else:
            out.append((k, v))
    if not found:
        out.append(("page", str(page)))
    return urlunsplit((p.scheme, p.netloc, p.path, urlencode(out), p.fragment))

def http_get(url, headers, timeout=30):
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            status = getattr(resp, "status", resp.getcode())
            body = resp.read()
            ctype = resp.headers.get("Content-Type", "")
            charset = resp.headers.get_content_charset() or "utf-8"
            return status, ctype, body.decode(charset, errors="replace"), resp.headers
    except urllib.error.HTTPError as e:
        body = e.read()
        try:
            charset = e.headers.get_content_charset() or "utf-8"
        except Exception:
            charset = "utf-8"
        return e.code, e.headers.get("Content-Type", ""), body.decode(charset, errors="replace"), e.headers

def request_json_with_retry(url, headers, log, max_retries=5):
    attempt = 0
    while True:
        status, ctype, text, resp_headers = http_get(url, headers)

        if status == 200:
            try:
                return json.loads(text)
            except Exception as e:
                raise RuntimeError(
                    f"HTTP 200でしたがJSONとして読めませんでした。\n"
                    f"Content-Type: {ctype}\n先頭300文字:\n{text[:300]}"
                ) from e

        if status in (401, 403):
            raise RuntimeError(
                f"HTTP {status}: 認証系エラーのため停止します。\n\n"
                f"レスポンス先頭500文字:\n{text[:500]}"
            )

        if status == 429 or 500 <= status <= 599:
            if attempt >= max_retries:
                raise RuntimeError(
                    f"HTTP {status}: {max_retries}回再試行しても成功しませんでした。\n\n"
                    f"レスポンス先頭500文字:\n{text[:500]}"
                )
            try:
                ra = resp_headers.get("Retry-After")
                wait = float(ra) if ra else min(5 * (2 ** attempt), 60)
            except Exception:
                wait = min(5 * (2 ** attempt), 60)

            log(f"HTTP {status} → {wait:.1f}秒待って再試行")
            time.sleep(wait)
            attempt += 1
            continue

        raise RuntimeError(
            f"HTTP {status}: 取得できませんでした。\n\n"
            f"レスポンス先頭800文字:\n{text[:800]}"
        )

def mail_to_row(m, page):
    member = m.get("member") or {}
    return {
        "mail_id": m.get("id", ""),
        "receive_datetime": m.get("receive_datetime", ""),
        "receive_time": m.get("receive_time", ""),
        "subject": m.get("subject", ""),
        "member_id": member.get("id", ""),
        "member_name": member.get("name", ""),
        "detail_url": m.get("detail_url", ""),
        "is_image": m.get("is_image", ""),
        "is_unread": m.get("is_unread", ""),
        "is_star": m.get("is_star", ""),
        "source_page": page,
        "content_preview": m.get("content", ""),
    }

def safe_filename(s):
    return re.sub(r'[\\/:*?"<>|]', "_", str(s or "unknown")).strip()[:80] or "unknown"

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("AKB48 Mail STEP1 ID取得 v5")
        self.geometry("930x790")
        self.minsize(800, 680)
        self.running = False

        root = ttk.Frame(self, padding=12)
        root.pack(fill="both", expand=True)

        ttk.Label(
            root,
            text="① /v1/inbox の成功しているURLを貼り付け",
            font=("", 11, "bold")
        ).pack(anchor="w")

        ttk.Label(
            root,
            text="全員分なら、公式アプリでメンバーを選んでいない受信一覧のURLを推奨します。"
        ).pack(anchor="w", pady=(2, 4))

        self.url_var = tk.StringVar(
            value="https://api.akb48mail-appli.com/v1/inbox?is_information=0&is_star=0&is_unread=0&page=1"
        )
        ttk.Entry(root, textvariable=self.url_var).pack(fill="x", pady=(0, 14))

        ttk.Label(
            root,
            text="② Request Headers をそのまま貼り付け",
            font=("", 11, "bold")
        ).pack(anchor="w")

        ttk.Label(
            root,
            text="User-Id / Access-Token等は外部送信せず、結果ファイルにも保存しません。"
        ).pack(anchor="w", pady=(2, 4))

        self.headers_text = tk.Text(root, height=18, wrap="none")
        self.headers_text.pack(fill="both", expand=True)

        opts = ttk.Frame(root)
        opts.pack(fill="x", pady=12)

        ttk.Label(opts, text="ページ間隔（秒）:").pack(side="left")
        self.interval_var = tk.StringVar(value="0.5")
        ttk.Entry(opts, width=8, textvariable=self.interval_var).pack(side="left", padx=(6, 18))

        ttk.Label(opts, text="開始ページ:").pack(side="left")
        self.start_page_var = tk.StringVar(value="1")
        ttk.Entry(opts, width=8, textvariable=self.start_page_var).pack(side="left", padx=(6, 18))

        ttk.Label(opts, text="取得ページ数（0=最後まで）:").pack(side="left")
        self.repeat_pages_var = tk.StringVar(value="1")
        ttk.Entry(opts, width=8, textvariable=self.repeat_pages_var).pack(side="left", padx=(6, 18))

        self.start_btn = ttk.Button(opts, text="取得開始", command=self.start)
        self.start_btn.pack(side="right")

        ttk.Separator(root).pack(fill="x", pady=(0, 10))
        ttk.Label(root, text="進捗", font=("", 11, "bold")).pack(anchor="w")
        self.log_text = tk.Text(root, height=13, state="disabled")
        self.log_text.pack(fill="both", expand=True, pady=(4, 0))

    def log(self, text):
        self.after(0, self._log_ui, text)

    def _log_ui(self, text):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", text + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def start(self):
        if self.running:
            return

        url = self.url_var.get().strip()
        raw_headers = self.headers_text.get("1.0", "end").strip()

        try:
            validate_url(url)
            interval = float(self.interval_var.get())
            if interval < 0:
                raise ValueError("ページ間隔は0以上にしてください。")
            start_page = int(self.start_page_var.get())
            if start_page < 1:
                raise ValueError("開始ページは1以上にしてください。")
            repeat_pages = int(self.repeat_pages_var.get())
            if repeat_pages < 0:
                raise ValueError("取得ページ数は0以上にしてください。")
            headers = parse_headers(raw_headers)
            if not headers:
                raise ValueError("Request Headersを貼り付けてください。")
        except ValueError as e:
            messagebox.showerror("入力エラー", str(e))
            return

        q = query_dict(url)
        if q.get("member_id"):
            ok = messagebox.askyesno(
                "メンバー指定URLです",
                "このURLには member_id が含まれています。\n\n"
                f"member_id = {q.get('member_id')}\n\n"
                "このまま進めると、そのメンバーの一覧だけを取得する可能性があります。\n"
                "全員分を取得したい場合は、公式アプリでメンバーを選んでいない一覧の"
                "成功URLを貼るのがおすすめです。\n\n"
                "このURLのまま続けますか？"
            )
            if not ok:
                return

        lower = {k.lower(): v for k, v in headers.items()}
        missing = [x for x in ("user-id", "access-token") if x not in lower]
        if missing:
            if not messagebox.askyesno(
                "確認",
                "次のヘッダーが見つかりません:\n"
                + "\n".join(missing)
                + "\n\nそれでも試しますか？"
            ):
                return

        save_dir = filedialog.askdirectory(title="結果の保存先を選択")
        if not save_dir:
            return

        self.running = True
        self.start_btn.configure(state="disabled")
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.configure(state="disabled")

        threading.Thread(
            target=self.worker,
            args=(url, headers, interval, start_page, repeat_pages, Path(save_dir)),
            daemon=True
        ).start()

    def worker(self, base_url, headers, interval, start_page, repeat_pages, save_dir):
        try:
            result_dir = save_dir / "AKB_API_ID取得結果"
            result_dir.mkdir(parents=True, exist_ok=True)

            q = query_dict(base_url)
            mode = "メンバー指定" if q.get("member_id") else "全体一覧"
            self.log(f"モード判定: {mode}")
            if q.get("member_id"):
                self.log(f"member_id={q.get('member_id')}")
            else:
                self.log("member_idなし → レスポンス内のメンバー情報で自動分類します。")
            self.log("")

            all_mails = {}
            page = start_page
            page_count = 0

            while True:
                url = set_page(base_url, page)
                self.log(f"page={page} 取得中...")

                data = request_json_with_retry(url, headers, self.log)
                mails = data.get("mails")

                if not isinstance(mails, list):
                    raise RuntimeError(
                        f"page={page}: mails配列が見つかりません。\n"
                        f"JSON keys: {list(data.keys())[:30]}"
                    )

                added = 0
                for m in mails:
                    if not isinstance(m, dict):
                        continue
                    mid = m.get("id")
                    if not mid:
                        continue
                    if mid not in all_mails:
                        added += 1
                    all_mails[mid] = mail_to_row(m, page)

                has_next = data.get("has_next_page")
                self.log(
                    f"  OK / {len(mails)}件 / 新規{added}件 / "
                    f"累計{len(all_mails)}件 / has_next_page={has_next}"
                )

                page_count += 1

                if repeat_pages and page_count >= repeat_pages:
                    self.log("")
                    self.log(f"指定した取得ページ数 {repeat_pages} に達したため終了。")
                    break

                if has_next is False:
                    self.log("")
                    self.log("has_next_page=false を確認。最終ページです。")
                    break

                if has_next is None and len(mails) == 0:
                    self.log("")
                    self.log("mails=0件のため終了します。")
                    break

                if page_count >= 5000:
                    raise RuntimeError("5000ページに達したため安全のため停止しました。")

                page += 1
                time.sleep(interval)

            rows = list(all_mails.values())
            rows.sort(
                key=lambda r: (str(r["receive_datetime"]), str(r["mail_id"])),
                reverse=True
            )

            with (result_dir / "STEP2入力用_全メール一覧.csv").open(
                "w", newline="", encoding="utf-8-sig"
            ) as f:
                w = csv.DictWriter(f, fieldnames=FIELDS)
                w.writeheader()
                w.writerows(rows)

            (result_dir / "全MailID一覧.txt").write_text(
                "\n".join(r["mail_id"] for r in rows if r["mail_id"]),
                encoding="utf-8"
            )

            by_member = {}
            for r in rows:
                key = (str(r["member_id"]), str(r["member_name"]))
                by_member.setdefault(key, []).append(r)

            member_summary = []
            for (member_id, member_name), mrows in sorted(
                by_member.items(),
                key=lambda x: (-len(x[1]), x[0][1])
            ):
                if not member_id and not member_name:
                    continue

                base = f"{safe_filename(member_name)}_{member_id or 'unknown'}"

                with (result_dir / f"確認用_メンバー別_{base}.csv").open(
                    "w", newline="", encoding="utf-8-sig"
                ) as f:
                    w = csv.DictWriter(f, fieldnames=FIELDS)
                    w.writeheader()
                    w.writerows(mrows)

                (result_dir / f"確認用_メンバー別_{base}.txt").write_text(
                    "\n".join(r["mail_id"] for r in mrows if r["mail_id"]),
                    encoding="utf-8"
                )

                member_summary.append(
                    f"{member_name or 'unknown'} (ID:{member_id or 'unknown'}): {len(mrows)}件"
                )

            summary_lines = [
                "AKB48 Mail STEP1 ID取得 v5",
                "",
                f"取得モード: {mode}",
                f"取得ページ数: {page_count}",
                f"取得Mail ID数: {len(rows)}",
                f"検出メンバー数: {len(member_summary)}",
                f"開始ページ: {start_page}",
                f"最終ページ: {page}",
                f"取得ページ数指定: {repeat_pages if repeat_pages else '最後まで'}",
                "",
                "メンバー別件数:",
                *member_summary,
                "",
                "Request Headers、User-Id、Access-Tokenは保存していません。",
            ]

            (result_dir / "STEP1取得結果.txt").write_text(
                "\n".join(summary_lines),
                encoding="utf-8-sig"
            )

            self.log("")
            self.log(f"完了: {len(rows)}件 / {len(member_summary)}メンバー")
            self.log(f"保存先: {result_dir}")

            self.after(0, lambda: messagebox.showinfo(
                "完了",
                f"取得完了\n\n"
                f"Mail ID: {len(rows)}件\n"
                f"メンバー: {len(member_summary)}人\n"
                f"ページ: {page_count}ページ\n\n"
                f"保存先:\n{result_dir}"
            ))

        except Exception as e:
            self.log("")
            self.log("エラー:")
            self.log(str(e))
            self.log("")
            self.log(traceback.format_exc())
            self.after(
                0,
                lambda err=str(e): messagebox.showerror("取得エラー", err)
            )
        finally:
            self.running = False
            self.after(0, lambda: self.start_btn.configure(state="normal"))

if __name__ == "__main__":
    App().mainloop()
