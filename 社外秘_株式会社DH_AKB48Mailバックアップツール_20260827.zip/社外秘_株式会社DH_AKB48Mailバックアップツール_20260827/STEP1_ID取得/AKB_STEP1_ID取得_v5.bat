﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (
    py "AKB_STEP1_ID取得_v5.py"
) else (
    python "AKB_STEP1_ID取得_v5.py"
)
if errorlevel 1 pause
